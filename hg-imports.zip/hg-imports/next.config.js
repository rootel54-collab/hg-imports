module.exports={images:{formats:['image/avif','image/webp'],remotePatterns:[{protocol:'https',hostname:'**.supabase.co'}]}}
